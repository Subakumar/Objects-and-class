package hcl5;

public class Wicket {
private long ball;
private long run;
private String playername;
private String wickettype;
private String bowlername;

public Wicket() {
	
}

public Wicket(long ball, long run, String playername, String wickettype, String bowlername) {
	super();
	this.ball = ball;
	this.run = run;
	this.playername = playername;
	this.wickettype = wickettype;
	this.bowlername = bowlername;
}

public long getBall() {
	return ball;
}

public void setBall(long ball) {
	this.ball = ball;
}

public long getRun() {
	return run;
}

public void setRun(long run) {
	this.run = run;
}

public String getPlayername() {
	return playername;
}

public void setPlayername(String playername) {
	this.playername = playername;
}

public String getWickettype() {
	return wickettype;
}

public void setWickettype(String wickettype) {
	this.wickettype = wickettype;
}

public String getBowlername() {
	return bowlername;
}

public void setBowlername(String bowlername) {
	this.bowlername = bowlername;
}

}

