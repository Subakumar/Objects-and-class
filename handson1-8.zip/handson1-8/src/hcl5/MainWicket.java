package hcl5;
import java.util.*;


public class MainWicket {

	public static void main(String[] args) {
		Wicket w1 = new Wicket();
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the number of wickets:");
		int su= s.nextInt();
		String str[] = new String[10];
		long run = 0;
		long ball;
		
		
		for(int i= 1;i<=su;i++) {
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter the details of wicket:");
			 str[i-1]  = sc.nextLine();
			}
		for(int i=0; i<su;i++) {
			String[] str1 = str[i].split(",");
			for(String string: str1) 
			run= Long.parseLong(str1[0]);
            ball = Long.parseLong(str1[1]);
            w1.setRun(run);
		w1.setBall(ball);
		w1.setPlayername(str1[2]);
		w1.setBowlername(str1[3]);
		w1.setWickettype(str1[4]);
		
		System.out.println(  "Player name1"+w1.getPlayername());
		System.out.println("Run:"+w1.getRun());
		System.out.println("Balls"+w1.getBall());
		System.out.println("BowlerName:"+w1.getBowlername());
		System.out.println("WicketType:"+w1.getWickettype());
		
		}
		
		
		
	}
		
}
